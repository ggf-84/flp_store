
export const socialData = [
  {
      id:1,
      icon: "FaFacebook" ,
      url:'https://www.facebook.com'
  },
  {
      id:2,
      icon:"FaTwitter",
      url:'https://www.twitter.com'
  },
  {
      id:3,
      icon:"FaLinkedin",
      url:'https://www.linkedin.com'
  }
];
