export const items = [
  {
      sys: { id: 0 },
      fields: {
      title: "google pixel - black",
      price: 450,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-0.png" } } }
      }
  },
  {
      sys: { id: 1 },

      fields: {
      title: "samsung s7 - white",
      price: 640,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-1.png" } } }
      }
  },
  {
      sys: { id: 2 },

      fields: {
      title: "htc 10 - black",
      price: 370,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-2.png" } } }
      }
  },
  {
      sys: { id: 3 },

      fields: {
      title: "htc 10 - white",
      price: 360,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-3.png" } } }
      }
  },
  {
      sys: { id: 4 },

      fields: {
      title: "samsung s7 - black",
      price: 670,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-4.png" } } }
      }
  },
  {
      sys: { id: 5 },

      fields: {
      title: "samsung galaxy A8 - black",
      price: 450,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-5.png" } } }
      }
  },

  {
      sys: { id: 6 },

      fields: {
      title: "fuji X100s photo camera",
      price: 290,
      company: "fuji",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-6.png" } } }
      }
  },
  {
      sys: { id: 7 },

      fields: {
      title: "canon Eos 30 photo camera",
      price: 190,
      company: "canon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-7.png" } } }
      }
  },
  {
      sys: { id: 8 },

      fields: {
      title: "nikon D 3100 photo camera",
      price: 535,
      company: "nikon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-8.png" } } }
      }
  },
  {
      sys: { id: 9 },

      fields: {
      title: "acer desktop computer",
      price: 735,
      company: "acer",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-9.png" } } }
      }
  },
  {
      sys: { id: 10 },

      fields: {
      title: "hp desktop computer",
      price: 975,
      company: "hp",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-10.png" } } }
      }
  },
  {
      sys: { id: 11 },

      fields: {
      title: "lenovo desktop computer",
      price: 510,
      company: "lenovo",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-11.png" } } }
      }
  },
  {
      sys: { id: 12 },

      fields: {
      title: "dell desktop computer",
      price: 728,
      company: "dell",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-12.png" } } }
      }
  },
  {
      sys: { id: 13 },
      fields: {
      title: "google pixel - black",
      price: 450,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-0.png" } } }
      }
  },
  {
      sys: { id: 14 },

      fields: {
      title: "samsung s7 - white",
      price: 640,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-1.png" } } }
      }
  },
  {
      sys: { id: 15 },

      fields: {
      title: "htc 10 - black",
      price: 370,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-2.png" } } }
      }
  },
  {
      sys: { id: 17 },

      fields: {
      title: "htc 10 - white",
      price: 360,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-3.png" } } }
      }
  },
  {
      sys: { id: 18 },

      fields: {
      title: "samsung s7 - black",
      price: 670,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-4.png" } } }
      }
  },
  {
      sys: { id: 19 },

      fields: {
      title: "samsung galaxy A8 - black",
      price: 450,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-5.png" } } }
      }
  },

  {
      sys: { id: 20 },

      fields: {
      title: "fuji X100s photo camera",
      price: 290,
      company: "fuji",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-6.png" } } }
      }
  },
  {
      sys: { id: 21 },

      fields: {
      title: "canon Eos 30 photo camera",
      price: 190,
      company: "canon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-7.png" } } }
      }
  },
  {
      sys: { id: 22 },

      fields: {
      title: "nikon D 3100 photo camera",
      price: 535,
      company: "nikon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-8.png" } } }
      }
  },
  {
      sys: { id: 23 },

      fields: {
      title: "acer desktop computer",
      price: 735,
      company: "acer",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-9.png" } } }
      }
  },
  {
      sys: { id: 24 },

      fields: {
      title: "hp desktop computer",
      price: 975,
      company: "hp",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-10.png" } } }
      }
  },
  {
      sys: { id: 25 },

      fields: {
      title: "lenovo desktop computer",
      price: 510,
      company: "lenovo",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-11.png" } } }
      }
  },
  {
      sys: { id: 26 },

      fields: {
      title: "dell desktop computer",
      price: 728,
      company: "dell",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-12.png" } } }
      }
  },
  {
      sys: { id: 27 },
      fields: {
      title: "google pixel - black",
      price: 450,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-0.png" } } }
      }
  },
  {
      sys: { id: 28 },

      fields: {
      title: "samsung s7 - white",
      price: 640,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-1.png" } } }
      }
  },
  {
      sys: { id: 29 },

      fields: {
      title: "htc 10 - black",
      price: 370,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-2.png" } } }
      }
  },
  {
      sys: { id: 30 },

      fields: {
      title: "htc 10 - white",
      price: 360,
      company: "htc",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-3.png" } } }
      }
  },
  {
      sys: { id: 31 },

      fields: {
      title: "samsung s7 - black",
      price: 670,
      company: "google",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-4.png" } } }
      }
  },
  {
      sys: { id: 32 },

      fields: {
      title: "samsung galaxy A8 - black",
      price: 450,
      company: "samsung",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-5.png" } } }
      }
  },

  {
      sys: { id: 33 },

      fields: {
      title: "fuji X100s photo camera",
      price: 290,
      company: "fuji",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-6.png" } } }
      }
  },
  {
      sys: { id: 34 },

      fields: {
      title: "canon Eos 30 photo camera",
      price: 190,
      company: "canon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-7.png" } } }
      }
  },
  {
      sys: { id: 35 },

      fields: {
      title: "nikon D 3100 photo camera",
      price: 535,
      company: "nikon",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-8.png" } } }
      }
  },
  {
      sys: { id: 36 },

      fields: {
      title: "acer desktop computer",
      price: 735,
      company: "acer",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-9.png" } } }
      }
  },
  {
      sys: { id: 37 },

      fields: {
      title: "hp desktop computer",
      price: 975,
      company: "hp",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,

      image: { fields: { file: { url: "img/product-10.png" } } }
      }
  },
  {
      sys: { id: 38 },

      fields: {
      title: "lenovo desktop computer",
      price: 510,
      company: "lenovo",
      freeShipping: false,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-11.png" } } }
      }
  },
  {
      sys: { id: 39 },

      fields: {
      title: "dell desktop computer",
      price: 728,
      company: "dell",
      freeShipping: true,
      description:
          "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
      featured: false,
      image: { fields: { file: { url: "img/product-12.png" } } }
      }
  },
  {
    sys: { id: 40 },
    fields: {
    title: "google pixel - black",
    price: 450,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-0.png" } } }
    }
  },
  {
    sys: { id: 41 },

    fields: {
    title: "samsung s7 - white",
    price: 640,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-1.png" } } }
    }
  },
  {
    sys: { id: 42 },

    fields: {
    title: "htc 10 - black",
    price: 370,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-2.png" } } }
    }
  },
  {
    sys: { id: 43 },

    fields: {
    title: "htc 10 - white",
    price: 360,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-3.png" } } }
    }
  },
  {
    sys: { id: 44 },

    fields: {
    title: "samsung s7 - black",
    price: 670,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-4.png" } } }
    }
  },
  {
    sys: { id: 45 },

    fields: {
    title: "samsung galaxy A8 - black",
    price: 450,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-5.png" } } }
    }
  },

  {
    sys: { id: 46 },

    fields: {
    title: "fuji X100s photo camera",
    price: 290,
    company: "fuji",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-6.png" } } }
    }
  },
  {
    sys: { id: 47 },

    fields: {
    title: "canon Eos 30 photo camera",
    price: 190,
    company: "canon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-7.png" } } }
    }
  },
  {
    sys: { id: 48 },

    fields: {
    title: "nikon D 3100 photo camera",
    price: 535,
    company: "nikon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-8.png" } } }
    }
  },
  {
    sys: { id: 49 },

    fields: {
    title: "acer desktop computer",
    price: 735,
    company: "acer",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-9.png" } } }
    }
  },
  {
    sys: { id: 50 },

    fields: {
    title: "hp desktop computer",
    price: 975,
    company: "hp",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-10.png" } } }
    }
  },
  {
    sys: { id: 51 },

    fields: {
    title: "lenovo desktop computer",
    price: 510,
    company: "lenovo",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-11.png" } } }
    }
  },
  {
    sys: { id: 52 },

    fields: {
    title: "dell desktop computer",
    price: 728,
    company: "dell",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-12.png" } } }
    }
  },
  {
    sys: { id: 53 },
    fields: {
    title: "google pixel - black",
    price: 450,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-0.png" } } }
    }
  },
  {
    sys: { id: 54 },

    fields: {
    title: "samsung s7 - white",
    price: 640,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-1.png" } } }
    }
  },
  {
    sys: { id: 55 },

    fields: {
    title: "htc 10 - black",
    price: 370,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-2.png" } } }
    }
  },
  {
    sys: { id: 56 },

    fields: {
    title: "htc 10 - white",
    price: 360,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-3.png" } } }
    }
  },
  {
    sys: { id: 57 },

    fields: {
    title: "samsung s7 - black",
    price: 670,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-4.png" } } }
    }
  },
  {
    sys: { id: 58 },

    fields: {
    title: "samsung galaxy A8 - black",
    price: 450,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-5.png" } } }
    }
  },

  {
    sys: { id: 59 },

    fields: {
    title: "fuji X100s photo camera",
    price: 290,
    company: "fuji",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-6.png" } } }
    }
  },
  {
    sys: { id: 60 },

    fields: {
    title: "canon Eos 30 photo camera",
    price: 190,
    company: "canon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-7.png" } } }
    }
  },
  {
    sys: { id: 61 },

    fields: {
    title: "nikon D 3100 photo camera",
    price: 535,
    company: "nikon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-8.png" } } }
    }
  },
  {
    sys: { id: 62 },

    fields: {
    title: "acer desktop computer",
    price: 735,
    company: "acer",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-9.png" } } }
    }
  },
  {
    sys: { id: 63 },

    fields: {
    title: "hp desktop computer",
    price: 975,
    company: "hp",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-10.png" } } }
    }
  },
  {
    sys: { id: 64 },

    fields: {
    title: "lenovo desktop computer",
    price: 510,
    company: "lenovo",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-11.png" } } }
    }
  },
  {
    sys: { id: 65 },

    fields: {
    title: "dell desktop computer",
    price: 728,
    company: "dell",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-12.png" } } }
    }
  },
  {
    sys: { id: 66 },
    fields: {
    title: "google pixel - black",
    price: 450,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-0.png" } } }
    }
  },
  {
    sys: { id: 67 },

    fields: {
    title: "samsung s7 - white",
    price: 640,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-1.png" } } }
    }
  },
  {
    sys: { id: 68 },

    fields: {
    title: "htc 10 - black",
    price: 370,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-2.png" } } }
    }
  },
  {
    sys: { id: 69 },

    fields: {
    title: "htc 10 - white",
    price: 360,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-3.png" } } }
    }
  },
  {
    sys: { id: 70 },

    fields: {
    title: "samsung s7 - black",
    price: 670,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-4.png" } } }
    }
  },
  {
    sys: { id: 71 },

    fields: {
    title: "samsung galaxy A8 - black",
    price: 450,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-5.png" } } }
    }
  },

  {
    sys: { id: 72 },

    fields: {
    title: "fuji X100s photo camera",
    price: 290,
    company: "fuji",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-6.png" } } }
    }
  },
  {
    sys: { id: 74 },

    fields: {
    title: "canon Eos 30 photo camera",
    price: 190,
    company: "canon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-7.png" } } }
    }
  },
  {
    sys: { id: 174 },

    fields: {
    title: "nikon D 3100 photo camera",
    price: 535,
    company: "nikon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-8.png" } } }
    }
  },
  {
    sys: { id: 75 },

    fields: {
    title: "acer desktop computer",
    price: 735,
    company: "acer",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-9.png" } } }
    }
  },
  {
    sys: { id: 76 },

    fields: {
    title: "hp desktop computer",
    price: 975,
    company: "hp",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-10.png" } } }
    }
  },
  {
    sys: { id: 77 },

    fields: {
    title: "lenovo desktop computer",
    price: 510,
    company: "lenovo",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-11.png" } } }
    }
  },
  {
    sys: { id: 78 },

    fields: {
    title: "dell desktop computer",
    price: 728,
    company: "dell",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-12.png" } } }
    }
  },
  {
    sys: { id: 79 },
    fields: {
    title: "google pixel - black",
    price: 450,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-0.png" } } }
    }
  },
  {
    sys: { id: 80 },

    fields: {
    title: "samsung s7 - white",
    price: 640,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-1.png" } } }
    }
  },
  {
    sys: { id: 81 },

    fields: {
    title: "htc 10 - black",
    price: 370,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-2.png" } } }
    }
  },
  {
    sys: { id: 82 },

    fields: {
    title: "htc 10 - white",
    price: 360,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-3.png" } } }
    }
  },
  {
    sys: { id: 83 },

    fields: {
    title: "samsung s7 - black",
    price: 670,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-4.png" } } }
    }
  },
  {
    sys: { id: 84 },

    fields: {
    title: "samsung galaxy A8 - black",
    price: 450,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-5.png" } } }
    }
  },

  {
    sys: { id: 85 },

    fields: {
    title: "fuji X100s photo camera",
    price: 290,
    company: "fuji",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-6.png" } } }
    }
  },
  {
    sys: { id: 86 },

    fields: {
    title: "canon Eos 30 photo camera",
    price: 190,
    company: "canon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-7.png" } } }
    }
  },
  {
    sys: { id: 87 },

    fields: {
    title: "nikon D 3100 photo camera",
    price: 535,
    company: "nikon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-8.png" } } }
    }
  },
  {
    sys: { id: 88 },

    fields: {
    title: "acer desktop computer",
    price: 735,
    company: "acer",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-9.png" } } }
    }
  },
  {
    sys: { id: 89 },

    fields: {
    title: "hp desktop computer",
    price: 975,
    company: "hp",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-10.png" } } }
    }
  },
  {
    sys: { id: 90 },

    fields: {
    title: "lenovo desktop computer",
    price: 510,
    company: "lenovo",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-11.png" } } }
    }
  },
  {
    sys: { id: 91 },

    fields: {
    title: "dell desktop computer",
    price: 728,
    company: "dell",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-12.png" } } }
    }
  },
  {
    sys: { id: 92 },
    fields: {
    title: "google pixel - black",
    price: 450,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: true,
    image: { fields: { file: { url: "img/product-0.png" } } }
    }
  },
  {
    sys: { id: 93 },

    fields: {
    title: "samsung s7 - white",
    price: 640,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-1.png" } } }
    }
  },
  {
    sys: { id: 94 },

    fields: {
    title: "htc 10 - black",
    price: 370,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-2.png" } } }
    }
  },
  {
    sys: { id: 95 },

    fields: {
    title: "htc 10 - white",
    price: 360,
    company: "htc",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-3.png" } } }
    }
  },
  {
    sys: { id: 96 },

    fields: {
    title: "samsung s7 - black",
    price: 670,
    company: "google",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-4.png" } } }
    }
  },
  {
    sys: { id: 97 },

    fields: {
    title: "samsung galaxy A8 - black",
    price: 450,
    company: "samsung",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-5.png" } } }
    }
  },

  {
    sys: { id: 98 },

    fields: {
    title: "fuji X100s photo camera",
    price: 290,
    company: "fuji",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: true,

    image: { fields: { file: { url: "img/product-6.png" } } }
    }
  },
  {
    sys: { id: 99 },

    fields: {
    title: "canon Eos 30 photo camera",
    price: 190,
    company: "canon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-7.png" } } }
    }
  },
  {
    sys: { id: 100 },

    fields: {
    title: "nikon D 3100 photo camera",
    price: 535,
    company: "nikon",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-8.png" } } }
    }
  },
  {
    sys: { id: 101 },

    fields: {
    title: "acer desktop computer",
    price: 735,
    company: "acer",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: true,

    image: { fields: { file: { url: "img/product-9.png" } } }
    }
  },
  {
    sys: { id: 102 },

    fields: {
    title: "hp desktop computer",
    price: 975,
    company: "hp",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,

    image: { fields: { file: { url: "img/product-10.png" } } }
    }
  },
  {
    sys: { id: 103 },

    fields: {
    title: "lenovo desktop computer",
    price: 510,
    company: "lenovo",
    freeShipping: false,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-11.png" } } }
    }
  },
  {
    sys: { id: 104 },

    fields: {
    title: "dell desktop computer",
    price: 728,
    company: "dell",
    freeShipping: true,
    description:
        "Shaman hexagon fam activated charcoal literally cardigan. Pitchfork YOLO man bun hella. Trust fund vexillologist squid put a bird on it man braid, selvage pug. Schlitz kombucha chillwave pug shabby chic cornhole. Try-hard four loko listicle yuccie kitsch small batch narwhal celiac selfies distillery cloud bread farm-to-table art party leggings glossier.",
    featured: false,
    image: { fields: { file: { url: "img/product-12.png" } } }
    }
  }
];
